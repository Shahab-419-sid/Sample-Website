export { default } from "./Page";
